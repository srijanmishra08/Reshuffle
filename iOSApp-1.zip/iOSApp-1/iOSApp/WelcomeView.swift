//
//  WelcomeView.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 04/03/24.
//

import SwiftUI

struct WelcomeView: View {
    @State private var isTaglineVisible = false
    
    var body: some View {
        VStack {
            Spacer()
            
            Text("Reshuffle")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .transition(.move(edge: .top).combined(with: .opacity))
                .animation(.easeInOut(duration: 1.5))
                .padding()
            
            if isTaglineVisible {
                Text("Reshuffle - the future of business cards, right in your pocket")
                    .font(.headline)
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                    .transition(.opacity)
                    .animation(.easeInOut(duration: 1))
            }
            
            Spacer()
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    isTaglineVisible.toggle()
                }
            }
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
