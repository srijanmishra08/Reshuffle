import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore

struct LoginView: View {
    @AppStorage("isLoggedIn") var isLoggedIn = false
    @State private var email = ""
    @State private var password = ""
    @State private var isSignupActive = false
    @State private var isOnboardingActive = false
    @ObservedObject var userData: UserData
    @State private var isErrorAlertPresented = false
    @State private var errorMessage = ""

    var body: some View {
        NavigationView {
            VStack {
                Spacer()

                Text("Welcome back")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()

                VStack(spacing: 16) {
                    TextField("Email or username", text: $email)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)

                    SecureField("Password", text: $password)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                }
                .padding(.horizontal)

                HStack {
                    Spacer()
                    Button(action: {
                        resetPassword()
                    }) {
                        Text("Forgot password?")
                            .foregroundColor(.blue)
                    }
                    .padding()
                }

                NavigationLink(destination: FirstPage().navigationBarBackButtonHidden(true), isActive: $isOnboardingActive) {
                    Button(action: {
                        loginWithFirebase()
                    }) {
                        Text("Log in")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(200)
                    }
                    .padding(.horizontal)
                }

                Text("OR")
                    .font(.caption)
                    .foregroundColor(.black)
                    .padding(.top, 8)

                Text("Continue with")
                    .foregroundColor(.black)

                HStack {
                    Button(action: {
                        loginWithApple()
                    }) {
                        Image(systemName: "applelogo")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.black)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(200)
                    }
                    .padding(.horizontal)

                    Button(action: {
                        loginWithGoogle()
                    }) {
                        Image("googlelogo")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.black)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(200)
                    }
                    .padding(.horizontal)
                }

                HStack {
                    Text("Don’t have an account?")

                    NavigationLink(destination: SignupView(userData: userData).navigationBarBackButtonHidden(true), isActive: $isSignupActive) {
                        EmptyView()
                    }
                    .hidden()

                    Button(action: {
                        isSignupActive = true
                    }) {
                        Text("Sign up")
                            .foregroundColor(.blue)
                            .fontWeight(.bold)
                    }
                }
                .padding()

                Spacer()
            }
            .navigationBarTitle("Log In")
            .alert(isPresented: $isErrorAlertPresented) {
                Alert(title: Text("Error"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
            }
        }
        .onAppear {
            // Check persistent login status
            if !isLoggedIn { // Check if the user is not logged in
                // If not logged in, do not navigate to Onboarding
                isOnboardingActive = false
            }
        }
    }

    private func loginWithFirebase() {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error signing in: \(error.localizedDescription)")
                errorMessage = "Invalid email or password. Please try again."
                isErrorAlertPresented = true
            } else {
                // Successfully signed in
                print("Successfully signed in!")

                // Set persistent login status
                isLoggedIn = true

                // Trigger navigation to Onboarding
                withAnimation {
                    isOnboardingActive = true
                }
            }
        }
    }

    private func loginWithApple() {
        // Implement Apple Sign-In logic if needed
        print("Log in using Apple")
    }

    private func loginWithGoogle() {
        // Implement Google Sign-In logic if needed
        print("Log in using Google")
    }

    private func resetPassword() {
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let error = error {
                print("Error sending password reset email: \(error.localizedDescription)")
                errorMessage = "Error sending password reset email. Please try again."
                isErrorAlertPresented = true
            } else {
                print("Password reset email sent successfully!")
                errorMessage = "Password reset email sent successfully. Check your inbox."
                isErrorAlertPresented = true
            }
        }
    }
}


struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        let userData = UserData() // Create UserData instance
        LoginView(userData: userData)
    }
}
