//
//  iOSAppApp.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 12/12/23.
//

import SwiftUI
import Firebase
import GoogleSignIn

@main

struct iOSAppApp: App {
    init() {
            FirebaseApp.configure()
    }
    let userData = UserData()
    var body: some Scene {
        WindowGroup {
                ContentView()
                    .environmentObject(userData)
            }
        }
    }
